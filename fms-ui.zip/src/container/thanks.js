import React from 'react';


const Thanks = () => {

    return (

        <div className="container mt-3" >
        <div className=" row justify-content-center ml-3">
        <img src={require('../thank.jpg')} width="80%" height="50%" alt="Img not Supported" />
       </div>
       </div>
    );

}

export default Thanks
import { createBrowserHistory } from 'history';
const history = createBrowserHistory();

const userCredentials = {
    
}
export default history;
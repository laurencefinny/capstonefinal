package com.cognizant.repository;

import java.util.Optional;

import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;

import com.cognizant.model.Questions;
import com.fasterxml.jackson.databind.ObjectMapper;

import reactor.core.publisher.Mono;

public interface QuestionsRepository extends ReactiveCrudRepository<Questions, Integer> {
	@Query("select * from questions where fb_type = ?type")
	Mono<Questions>findByType(String type);

	// @Query("select * from questions where id = ?queId")
	// Mono<Questions> findById(String queId);

}
package com.cognizant;
//package com.fms;
//
//import org.aspectj.weaver.patterns.TypePatternQuestions.Question;
//import org.junit.jupiter.api.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.http.MediaType;
//import org.springframework.test.context.ActiveProfiles;
//import org.springframework.test.web.reactive.server.WebTestClient;
//
//import reactor.core.publisher.Mono;
//
//@ActiveProfiles("test")
//@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
//public class QuestionControllerTest {
//	@Autowired
//	private WebTestClient webTestClient;
//
//	@Test
//	public void testGetFeedbackQuestions() {
//		webTestClient.get().uri("/feedback-questions").accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk();
//	}
//	
//	@Test
//	public void testGetAllQuestion() {
//		webTestClient.get().uri("/questions").accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk();
//	}
//
//	@Test
//	public void testGetQuestion() {
//		webTestClient.get().uri("/questions/{questionId}",1).accept(MediaType.APPLICATION_JSON).exchange().expectStatus().isOk()
//				.expectBody(Question.class).value(qn -> System.out.println(qn));
//	}
//
//
//	
//	@Test
//    public void testDeleteQuestion() {
//
//        webTestClient.delete()
//                .uri("/delete-questions/12")
//                .exchange()
//                .expectStatus().isOk()
//                .expectBody(Void.class);
//    }
//}
